import streamlit as st
import requests
import json

# Page configuration
st.set_page_config(
    page_title="DemandFlow",
    page_icon="📊",
    layout="centered"
)

# Backend URL
BACKEND_URL = "http://localhost:8000"

def call_backend(data):
    """Call FastAPI backend for prediction"""
    try:
        response = requests.post(f"{BACKEND_URL}/predict", json=data, timeout=30)
        if response.status_code == 200:
            return response.json()
        else:
            return {"error": f"Backend error: {response.status_code}"}
    except Exception as e:
        return {"error": f"Connection failed: {str(e)}"}

def main():
    st.title("📊 DemandFlow")
    st.markdown("**Ai Powered Demand Forecasting Using Time-LLM**")
    st.markdown("---")
    
    # Create form
    with st.form("forecast_form", clear_on_submit=False):
        col1, col2 = st.columns(2)
        
        with col1:
            city = st.text_input("🏙️ City", placeholder="Mumbai, Delhi, Bangalore...")
            product = st.text_input("📱 Product", placeholder="Mobile Phone, Laptop...")
        
        with col2:
            days = st.selectbox("📅 Forecast Period", [1, 7, 14, 21], format_func=lambda x: f"{x} day{'s' if x>1 else ''}")
            price = st.number_input("💰 Price (₹)", min_value=1.0, value=1000.0, step=100.0)
        
        discount = st.slider("🎯 Discount (%)", 0, 50, 0)
        
        # Submit button
        submitted = st.form_submit_button("🚀 Get Forecast", type="primary", use_container_width=True)
    
    # Process form submission
    if submitted:
        if not city or not product:
            st.error("❌ Please enter both City and Product")
            return
            
        # Show loading
        with st.spinner("🔮 Analyzing market data..."):
            # Prepare data
            forecast_data = {
                "city": city.strip(),
                "product": product.strip(), 
                "days_ahead": days,
                "price": float(price),
                "discount": float(discount)
            }
            
            # Call backend
            result = call_backend(forecast_data)
        
        # Display results
        if "error" in result:
            st.error(f"❌ {result['error']}")
            st.info("📊 Using fallback prediction: **55 units**")
        else:
            st.success("✅ Forecast Generated!")
            
            # Metrics
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("📦 Predicted Sales", f"{result.get('predicted_units', 55)} units")
            with col2:
                st.metric("📅 Period", f"{days} day{'s' if days>1 else ''}")
            with col3:
                st.metric("💰 Price", f"₹{price:,.0f}")
            
            # Explanation
            st.markdown("### 📝 Analysis")
            explanation = result.get('explanation', 'Market analysis completed successfully.')
            st.write(explanation)

if __name__ == "__main__":
    main()