import os
import pandas as pd
import numpy as np
from torch.utils.data import Dataset
from sklearn.preprocessing import StandardScaler, LabelEncoder
from utils.timefeatures import time_features

# (1) ETT_hour
class Dataset_ETT_hour(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='S', data_path='ETTh1.csv',
                 target='OT', scale=True, timeenc=0, freq='h',
                 percent=100, seasonal_patterns=None):
        if size is None:
            self.seq_len, self.label_len, self.pred_len = 96, 24, 24
        else:
            self.seq_len, self.label_len, self.pred_len = size
        assert flag in ['train','val','test']
        self.flag = flag
        self.features, self.target = features, target
        self.scale, self.timeenc, self.freq = scale, timeenc, freq
        self.percent = percent
        self.root_path, self.data_path = root_path, data_path
        self.__read_data__()
        self.enc_in = self.data_x.shape[-1]
        self.tot_len = len(self.data_x) - self.seq_len - self.pred_len + 1

    def __read_data__(self):
        df_raw = pd.read_csv(os.path.join(self.root_path, self.data_path))
        df_raw['date'] = pd.to_datetime(df_raw['date'])
        # slicing borders (pretrain logic omitted for brevity; same as original)
        # ...
        # select columns:
        if self.features in ['M','MS']:
            df_data = df_raw.iloc[:,1:]
        else:  # 'S'
            df_data = df_raw[[self.target]]
        # scaling
        if self.scale:
            n_train = int(len(df_data)*0.7)
            self.scaler = StandardScaler()
            self.scaler.fit(df_data.values[:n_train])
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values
        # time stamp encoding
        dates = df_raw['date'].values
        if self.timeenc==0:
            df_stamp = pd.DataFrame({
                'month': pd.DatetimeIndex(dates).month,
                'day':   pd.DatetimeIndex(dates).day,
                'weekday':pd.DatetimeIndex(dates).weekday,
                'hour':  pd.DatetimeIndex(dates).hour
            })
            data_stamp = df_stamp.values
        else:
            tf = time_features(dates, freq=self.freq)
            data_stamp = tf.transpose(1,0)

        # for simplicity use entire series:
        self.data_x = data
        self.data_y = data
        self.data_stamp = data_stamp

    def __getitem__(self, idx):
        s = idx % self.tot_len
        x = self.data_x[s:s+self.seq_len]
        y = self.data_y[s+self.seq_len-self.label_len:
                        s+self.seq_len-self.label_len+self.label_len+self.pred_len]
        xm = self.data_stamp[s:s+self.seq_len]
        ym = self.data_stamp[s+self.seq_len-self.label_len:
                             s+self.seq_len-self.label_len+self.label_len+self.pred_len]
        return x, y, xm, ym

    def __len__(self):
        return self.tot_len

    def inverse_transform(self, arr):
        return self.scaler.inverse_transform(arr)


# (2) ETT_minute — identical structure, just freq and date parsing differ
class Dataset_ETT_minute(Dataset_ETT_hour):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, freq='t', **kwargs)


# (3) Custom dataset (generic CSV)
class Dataset_Custom(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='S', data_path='custom.csv',
                 target=None, scale=True, timeenc=0, freq='h',
                 percent=100, seasonal_patterns=None):
        if size is None:
            self.seq_len, self.label_len, self.pred_len = 96, 48, 96
        else:
            self.seq_len, self.label_len, self.pred_len = size
        assert flag in ['train','val','test']
        self.flag = flag
        self.features, self.target = features, target
        self.scale, self.timeenc, self.freq = scale, timeenc, freq
        self.percent = percent
        self.root_path, self.data_path = root_path, data_path
        self.__read_data__()
        self.enc_in = self.data_x.shape[-1]
        self.tot_len = len(self.data_x) - self.seq_len - self.pred_len + 1

    def __read_data__(self):
        df = pd.read_csv(os.path.join(self.root_path, self.data_path))
        df['date'] = pd.to_datetime(df['date'])
        # train/val/test splits proportionally
        n = len(df)
        n_train = int(n*0.7); n_val=int(n*0.2)
        # slice data_x and data_y similarly
        data_arr = df.drop(columns=['date']).values
        if self.scale:
            self.scaler=StandardScaler(); self.scaler.fit(data_arr[:n_train])
            data_arr=self.scaler.transform(data_arr)
        stamps = df['date'].values
        # build data_stamp like above...
        self.data_x = data_arr
        self.data_y = data_arr
        self.data_stamp = data_arr  # placeholder

    def __getitem__(self, idx):
        # same sliding window logic
        return super().__getitem__(idx)

    def __len__(self):
        return self.tot_len

    def inverse_transform(self, arr):
        return self.scaler.inverse_transform(arr)


# (4) M4 dataset
class Dataset_M4(Dataset):
    def __init__(self, root_path, flag='train', size=None,
                 features='S', data_path=None, target=None,
                 scale=False, inverse=False, timeenc=0, freq='h',
                 seasonal_patterns='Yearly'):
        self.flag = flag
        self.features, self.target = features, target
        self.scale, self.inverse = scale, inverse
        self.timeenc, self.freq = timeenc, freq
        self.root_path = root_path
        if size is None:
            self.seq_len, self.label_len, self.pred_len = 96,48,96
        else:
            self.seq_len, self.label_len, self.pred_len = size
        self.seasonal_patterns = seasonal_patterns
        self.__read_data__()
        self.enc_in = 1
        self.tot_len = len(self.timeseries)

    def __read_data__(self):
        from data_provider.m4 import M4Dataset, M4Meta
        ds = M4Dataset.load(training=(self.flag=='train'),
                            dataset_file=self.root_path)
        vals = ds.values[ds.groups==self.seasonal_patterns]
        self.timeseries = [v[~np.isnan(v)] for v in vals]
        self.ids = ds.ids[ds.groups==self.seasonal_patterns]

    def __getitem__(self, idx):
        ts = self.timeseries[idx]
        # implement sliding window or random window...
        window = ts[-self.seq_len:]
        return window, window, window, window

    def __len__(self):
        return len(self.timeseries)

    def inverse_transform(self, arr):
        return arr

    def last_insample_window(self):
        return np.zeros((len(self.timeseries), self.seq_len)), None

# (5) Retail dataset
class Dataset_Retail(Dataset):
    """
    Retail inventory dataset loader.
    Expects:
      - a 'Date' column,
      - a target column,
      - categorical columns (label-encoded),
      - continuous columns (scaled).
    """
    def __init__(
        self,
        root_path: str,
        data_path: str = "retail_inventory.csv",
        flag: str = "train",            # 'train', 'val', or 'test'
        size: list = None,              # [seq_len, label_len, pred_len]
        features: str = "M",            # 'M' multivariate or 'S' univariate
        target: str = "Units Sold",     # name of target column
        scale: bool = True,
        timeenc: int = 0,
        freq: str = "d",
        percent: int = 100,
        seasonal_patterns=None,
    ):
        # 1) sequence lengths
        if size is None:
            self.seq_len, self.label_len, self.pred_len = 30, 15, 5
        else:
            self.seq_len, self.label_len, self.pred_len = size

        # 2) split
        assert flag in ["train","val","test"], "flag must be train/val/test"
        split_map = {"train":0, "val":1, "test":2}
        self.set_type = split_map[flag]

        # 3) store params
        self.features, self.target = features, target
        self.scale, self.timeenc, self.freq = scale, timeenc, freq
        self.percent = percent
        self.root_path, self.data_path = root_path, data_path

        # 4) read & preprocess
        self._read_data()

        # 5) input dim & total windows
        self.enc_in = self.data_x.shape[-1]
        self.tot_len = len(self.data_x) - self.seq_len - self.pred_len + 1

    def _read_data(self):
        raw = pd.read_csv(os.path.join(self.root_path, self.data_path))

        # Detect date column
        date_cols = ['Date', 'date', 'DATE', 'timestamp', 'Timestamp', 'TIMESTAMP']
        date_col = None
        for col in date_cols:
            if col in raw.columns:
                date_col = col
                break
        if date_col is None:
            raise ValueError(f"No date column found. Expected one of: {date_cols}")

        # Rename date column to 'date'
        if date_col != "date":
            raw = raw.rename(columns={date_col: "date"})
        raw["date"] = pd.to_datetime(raw["date"])

        # Check target column
        if self.target not in raw.columns:
            raise ValueError(f"Target column '{self.target}' not found. Columns: {raw.columns.tolist()}")

        # Clean target column name
        original_target = self.target
        clean_target = self.target.strip().lower().replace(" ", "_").replace("/", "_").replace("-", "_")
        if original_target != clean_target:
            raw = raw.rename(columns={original_target: clean_target})
            self.target = clean_target

        # Sort by date
        raw = raw.sort_values("date").reset_index(drop=True)

        n = len(raw)
        n_train = int(n * 0.7)
        n_val = int(n * 0.2)

        # Label-encode categorical columns
        obj_cols = raw.select_dtypes(include=["object"]).columns.tolist()
        obj_cols = [c for c in obj_cols if c != "date"]
        self.label_encoders = {}
        for c in obj_cols:
            le = LabelEncoder()
            raw[c] = le.fit_transform(raw[c].astype(str))
            self.label_encoders[c] = le

        # Define split borders
        borders1 = [0, n_train - self.seq_len, n_train + n_val - self.seq_len]
        borders2 = [n_train, n_train + n_val, n]
        b1, b2 = borders1[self.set_type], borders2[self.set_type]
        b1 = max(0, b1)
        b2 = min(n, b2)

        if self.set_type == 0:
            available_len = b2 - b1 - self.seq_len
            if available_len > 0:
                subsample_len = available_len * self.percent // 100
                b2 = b1 + self.seq_len + subsample_len

        # Build feature matrix
        if self.features in ["M", "MS"]:
            df_data = raw.iloc[:, 1:]
        else:
            df_data = raw[[self.target]]

        vals = df_data.values.astype(float)

        # Scale and clip
        if self.scale:
            self.scaler = StandardScaler()
            self.scaler.fit(vals[:n_train])
            vals = self.scaler.transform(vals)

            # Clip outliers for stability
            vals = np.clip(vals, -5, +5)

            # Check for NaNs and Infs
            if np.isnan(vals).any():
                raise ValueError("Found NaN in scaled values!")
            if np.isinf(vals).any():
                raise ValueError("Found Inf in scaled values!")
        else:
            self.scaler = None

        # Time features
        df_stamp = raw[["date"]].iloc[b1:b2].copy()
        df_stamp["month"] = df_stamp["date"].dt.month
        df_stamp["day"] = df_stamp["date"].dt.day
        df_stamp["weekday"] = df_stamp["date"].dt.weekday
        df_stamp["hour"] = df_stamp["date"].dt.hour
        stamp = df_stamp.drop(columns="date").values

        # Final slices
        self.data_x = vals[b1:b2]
        self.data_y = vals[b1:b2]
        self.data_stamp = stamp

    def __len__(self):
        return self.tot_len

    def __getitem__(self, idx):
        start = idx
        end_x = start + self.seq_len
        end_y = start + self.seq_len + self.pred_len

        seq_x = self.data_x[start:end_x]
        seq_y = self.data_y[start + self.seq_len - self.label_len:end_y]
        stm_x = self.data_stamp[start:end_x]
        stm_y = self.data_stamp[start + self.seq_len - self.label_len:end_y]

        return seq_x, seq_y, stm_x, stm_y

    def inverse_transform(self, arr):
        if self.scaler is not None:
            return self.scaler.inverse_transform(arr)
        else:
            return arr
