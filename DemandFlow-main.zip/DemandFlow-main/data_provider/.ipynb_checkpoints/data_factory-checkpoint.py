from torch.utils.data import DataLoader
from data_provider.data_loader import Dataset_Retail, Dataset_ETT_hour, Dataset_ETT_minute, Dataset_Custom, Dataset_M4

DATASETS = {
    "retail": Dataset_Retail,
    "etth1":  Dataset_ETT_hour,
    "etth2":  Dataset_ETT_hour,
    "ettm1":  Dataset_ETT_minute,
    "ettm2":  Dataset_ETT_minute,
    "custom": Dataset_Custom,
    "m4":     Dataset_M4,
}

def data_provider(args, flag):
    key = args.data.lower()
    if key not in DATASETS:
        raise ValueError(f"Unknown dataset '{args.data}'. Available: {list(DATASETS.keys())}")
    DCls = DATASETS[key]

    init_kwargs = dict(
        root_path=args.root_path,
        data_path=args.data_path,
        flag=flag,
        size=[args.seq_len, args.label_len, args.pred_len],
        features=args.features,
        target=args.target,
        scale=True,
        timeenc=0 if getattr(args, "embed", "timeF")!="timeF" else 1,
        freq=args.freq,
        percent=getattr(args, "percent", 100),
    )
    ds = DCls(**init_kwargs)

    loader = DataLoader(
        ds,
        batch_size=(args.batch_size if flag!="test" else args.eval_batch_size),
        shuffle=(flag!="test"),
        num_workers=args.num_workers,
        drop_last=(flag!="test"),
    )
    return ds, loader