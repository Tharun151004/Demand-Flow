import os
import random
import pandas as pd
import torch
import argparse
from transformers import GPT2Config

GPT2_CACHE_DIR = "./models/gpt2-cache"
DATA_FILE = "./dataset/retail_inventory.csv"
CHECKPOINT = "./checkpoints/retail/checkpoint.pth"

def predict_units_sold(
    days_ahead,
    discount,
    holiday,
    comp_price,
    weather,
    seasonality,
    desired_price
):
    # 1) Load CSV (you can keep this if you eventually want exogenous features)
    df = pd.read_csv(DATA_FILE, parse_dates=["Date"])

    # 2) Load checkpoint & config
    ckpt = torch.load(CHECKPOINT, map_location="cpu")
    pred_len = ckpt["output_projection.linear.bias"].shape[0]
    llm_cfg = GPT2Config.from_pretrained(GPT2_CACHE_DIR)
    llm_layers = llm_cfg.num_hidden_layers

    # 3) Build args
    args = argparse.Namespace(
        model="TimeLLM",
        task_name="long_term_forecast",
        data="retail",
        root_path="./dataset",
        data_path="retail_inventory.csv",
        features="M",
        target="Units Sold",
        freq="d",
        percent=100,
        embed="timeF",
        seq_len=96,
        label_len=48,
        pred_len=pred_len,
        batch_size=4,
        eval_batch_size=4,
        learning_rate=1e-5,
        train_epochs=0,
        patience=0,
        num_workers=0,
        llm_model=GPT2_CACHE_DIR,
        llm_dim=768,
        llm_layers=llm_layers,
        n_heads=8,
        dropout=0.1,
        use_amp=False,
        d_model=512,
        d_ff=512
    )

    # 4) Data & loader
    from data_provider.data_factory import data_provider
    ds, loader = data_provider(args, flag="test")
    args.enc_in = ds.enc_in

    # 5) Load model
    from models.TimeLLM import Model
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = Model(args).to(device)
    model.load_state_dict(ckpt, strict=False)
    model.eval()
    if not hasattr(model, "top_k"):
        model.top_k = 5

    # 6) Inference
    seq_x, seq_y, stm_x, stm_y = next(iter(loader))
    seq_x, seq_y, stm_x, stm_y = [t.to(device).float() for t in (seq_x, seq_y, stm_x, stm_y)]
    zeros = torch.zeros_like(seq_y[:, -args.pred_len:, :]).to(device)
    dec_inp = torch.cat([seq_y[:, :args.label_len, :], zeros], dim=1)

    with torch.no_grad():
        out = model(seq_x, stm_x, dec_inp, stm_y)
    units_seq = out[0, :, 0].cpu().numpy()
    index = min(days_ahead - 1, args.pred_len - 1)
    raw_pred = float(units_seq[index])
    final_prediction = abs(round(raw_pred, 2)) * 100

    
    return final_prediction
